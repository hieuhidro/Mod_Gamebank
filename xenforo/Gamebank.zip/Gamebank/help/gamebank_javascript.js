function showpopup(){
	$("#popup-napcard").show();
	$("#exposeMask").show();
}