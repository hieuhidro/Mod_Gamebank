[bd] Banking
Start your xefonomics today.

[FEATURES]
1. Bonus fully integrated with posting thread, posting reply, liking, unliking, uploading attachment, downloading attachment
2. Easy to manage options in AdminCP. Please note that appearance configurations are setup as Style Properties so you may need to check that section before asking. To manage users' money and see history, head over to Tools > [bd] Banking
3. Importer integration: keep members' money from your vBulletin installation. Currently supports: vBCredits I, vBCredits II, kBank
4. Auto routing (default is "bank" but you can change to whatever you want)
5. Bonus for attachment upload and download, uploader can set price for each attachment!

[INSTALLATION]
1. Upload the library directory into your XenForo's
2. Import the addon
3. Configure options in Home > Options > [bd] Banking

[IMPORTANT]
1. Attachment Manager permission is a user group permission and it's not enabled by default.
2. Some elements are controlled by Style Properties:
	- Money in messages (in "Message Elements", enabled by default)
	- Money in visitor panel at the top of sidebar (in "Sidebar")
	- Bank tab in navigation (in "Header and Navigation", enabled by default)
	- Money in navigation, right next to Alerts (in "Header and Navigation", enabled by default)