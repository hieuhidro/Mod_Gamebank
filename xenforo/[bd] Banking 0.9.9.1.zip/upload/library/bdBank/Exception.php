<?php

class bdBank_Exception extends Zend_Exception {
	
}