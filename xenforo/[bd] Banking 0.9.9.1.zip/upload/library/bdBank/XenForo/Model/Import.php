<?php

class bdBank_XenForo_Model_Import extends XFCP_bdBank_XenForo_Model_Import {
	// intentionally left blank
}