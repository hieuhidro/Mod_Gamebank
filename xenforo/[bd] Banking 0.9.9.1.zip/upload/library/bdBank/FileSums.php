<?php

class bdBank_FileSums
{
	public static function getHashes()
	{
		return array (
  'library/bdBank/AlertHandler/Transaction.php' => '17a4e71e197a07c93bc23aa8ea6cca88',
  'library/bdBank/AntiCheating.php' => '9694fccb0fb8ac1d535e0814a8a85a14',
  'library/bdBank/bdShop/Pricing.php' => 'b66bc727d1032e97e3704aadee6ee53f',
  'library/bdBank/ControllerAdmin/Bank.php' => '5f573596669d884d52b8a38502fd84af',
  'library/bdBank/ControllerPublic/Bank.php' => 'f02ec1692cd38d62840912aaf08a173d',
  'library/bdBank/Exception.php' => '271bcd0d51cb532fd5ed9620bd34b8de',
  'library/bdBank/Importer/vBulletin.php' => 'c56431ab6a0888aea52cbcb7479ac72e',
  'library/bdBank/Listeners.php' => 'a2ce8f019f77ced761a7d125f30a06a9',
  'library/bdBank/Model/Bank.php' => '127fb4c478a771b26d0488e6ef05972e',
  'library/bdBank/Model/Personal.php' => 'e0c43af76ce8d399986f6b15ec06da15',
  'library/bdBank/Option/Field.php' => '36ca4424dc7f7b038310920f0e983ec6',
  'library/bdBank/Route/Prefix/Public.php' => '3a74d8f1e43c16657b603a53c08749e4',
  'library/bdBank/Route/PrefixAdmin/Bank.php' => '3231bc7317978593b589b3cb6ee27b69',
  'library/bdBank/Setup.php' => '1c63c93024b09da9f6233d535409c151',
  'library/bdBank/ViewPublic/Bank/TransferComplete.php' => '2cd941fa485facbe2356084ca6f1dd4a',
  'library/bdBank/XenForo/ControllerAdmin/Forum.php' => '2de8e0a17f21246cd413d09c96bb490f',
  'library/bdBank/XenForo/ControllerAdmin/User.php' => '6157afadae859aea87d14a615587d9b4',
  'library/bdBank/XenForo/ControllerPublic/Account.php' => 'd239424cfc77f8b33409c62169ebeca0',
  'library/bdBank/XenForo/ControllerPublic/Attachment.php' => '9ae7a929fbe710e7a9db995b0fb7fa97',
  'library/bdBank/XenForo/ControllerPublic/Thread.php' => '68636df07ae13ec7e7a1e6e77c7b79ed',
  'library/bdBank/XenForo/DataWriter/Attachment.php' => '885d62788453292c9ad2bf234a9eff8f',
  'library/bdBank/XenForo/DataWriter/Discussion/Thread.php' => '7f892a46e780f80a5cdb3a2b98c0df5e',
  'library/bdBank/XenForo/DataWriter/DiscussionMessage/Post.php' => 'eec12654a7914b42793f428f2bd5d2a0',
  'library/bdBank/XenForo/DataWriter/Forum.php' => '8c93b9a08ae0ce6843db17ad281fbbe2',
  'library/bdBank/XenForo/DataWriter/User.php' => '0ccd3e83be5465f532eebb1ee3c1c25e',
  'library/bdBank/XenForo/Model/Attachment.php' => '1776dc259b620ab2d9f6758e132afc76',
  'library/bdBank/XenForo/Model/Import.php' => 'f95665039883b8c10587515de6220d05',
  'library/bdBank/XenForo/Model/Like.php' => '1e62521bcefe69419193fbcaa3eba32a',
  'library/bdBank/XenForo/Model/Log.php' => 'a23c72f19c7df4badcaff262c11ae165',
  'library/bdBank/XenForo/Model/Thread.php' => '55d05d74108bd01545bc0871f049eafb',
  'js/bdBank/transfer.js' => 'dd3db694c9723f322f8e6826b2aa0165',
);
	}
}